const user_codeInput = document.querySelector(".phone");

const mask = new IMask(user_codeInput, {
  mask: "+380 00 000 00 00",
});
